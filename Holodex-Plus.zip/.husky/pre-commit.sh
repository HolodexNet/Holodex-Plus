#!/bin/sh
. "$(dirname "$0")/_/husky.sh"

pretty-quick --staged
