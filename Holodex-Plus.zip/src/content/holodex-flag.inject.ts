
// @ts-nocheck

window.ARCHIVE_CHAT_OVERRIDE = true;
window.HOLODEX_PLUS_INSTALLED = true;

export {};