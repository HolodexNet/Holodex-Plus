import{b as e}from"./browser-polyfill-7985a613.js";document.getElementById("options")?.addEventListener("click",(()=>e.exports.runtime.openOptionsPage()));
